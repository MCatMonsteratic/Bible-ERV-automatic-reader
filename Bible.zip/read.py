from pathlib import Path

# -------- Base path --------
BASE_DIR = Path(__file__).parent / "Files"

# -------- List of books in canonical order --------
CANONICAL_BOOKS = [
    "Genesis", "Exodus", "Leviticus", "Numbers", "Deuteronomy",
    "Joshua", "Judges", "Ruth", "1 Samuel", "2 Samuel",
    "1 Kings", "2 Kings", "1 Chronicles", "2 Chronicles",
    "Ezra", "Nehemiah", "Esther", "Job", "Psalms",
    "Proverbs", "Ecclesiastes", "Song of Solomon", "Isaiah",
    "Jeremiah", "Lamentations", "Ezekiel", "Daniel",
    "Hosea", "Joel", "Amos", "Obadiah", "Jonah",
    "Micah", "Nahum", "Habakkuk", "Zephaniah", "Haggai",
    "Zechariah", "Malachi", "Matthew", "Mark", "Luke",
    "John", "Acts", "Romans", "1 Corinthians", "2 Corinthians",
    "Galatians", "Ephesians", "Philippians", "Colossians",
    "1 Thessalonians", "2 Thessalonians", "1 Timothy",
    "2 Timothy", "Titus", "Philemon", "Hebrews", "James",
    "1 Peter", "2 Peter", "1 John", "2 John", "3 John",
    "Jude", "Revelation"
]

# -------- Functions --------
def list_books():
    books = []
    for idx, book in enumerate(CANONICAL_BOOKS, start=1):
        path = BASE_DIR / book
        if path.exists() and path.is_dir():
            books.append((book, idx))
    return books

def list_chapters(book):
    book_path = BASE_DIR / book
    if not book_path.exists():
        return []
    chapters = []
    for d in book_path.iterdir():
        if d.is_dir():
            try:
                chapters.append(int(d.name))
            except ValueError:
                continue
    return sorted(chapters)

def list_verses(book, chapter):
    chap_path = BASE_DIR / book / str(chapter)
    if not chap_path.exists():
        return []
    verses = []
    for f in chap_path.iterdir():
        if f.name.startswith("vers_") and f.suffix == ".bf":
            try:
                num = int(f.stem.split("_")[1])
                verses.append((num, f))
            except ValueError:
                continue
    return [f for _, f in sorted(verses)]

def read_verse(book, chapter, verse):
    verse_file = BASE_DIR / book / str(chapter) / f"vers_{verse}.bf"
    try:
        return verse_file.read_text(encoding="utf-8").strip()
    except Exception:
        return None

# -------- Main interactive session --------
def main():
    try:
        # Print books with Bible number
        print("\nAvailable books in the Bible:")
        books = list_books()
        for name, num in books:
            print(f"{name} [{num}]")

        # Choose book
        book_input = input("\nSelect a book by number: ").strip()
        try:
            book_idx = int(book_input)
            book_name = next(b for b, n in books if n == book_idx)
        except Exception:
            print("Invalid book number!")
            return

        # Choose chapter
        chapters = list_chapters(book_name)
        print(f"\nBook: {book_name}, Chapters available: {chapters}")
        chap_input = input("Enter chapter number: ").strip()
        try:
            chapter = int(chap_input)
            if chapter not in chapters:
                print("Chapter not found!")
                return
        except Exception:
            print("Invalid chapter!")
            return

        # List verses
        verses = list_verses(book_name, chapter)
        max_verse = len(verses)
        print(f"Chapter {chapter} has {max_verse} verses.")

        # Choose verse
        verse_input = input("Enter verse number (or 'all' for all verses): ").strip().lower()
        if verse_input == "all":
            print(f"\nPrinting all verses of {book_name} {chapter}:\n")
            for vf in verses:
                try:
                    print(vf.read_text(encoding="utf-8").strip())
                except Exception:
                    continue
        else:
            try:
                verse_num = int(verse_input)
                if 1 <= verse_num <= max_verse:
                    content = read_verse(book_name, chapter, verse_num)
                    print(f"\n{book_name} {chapter}:{verse_num} -> {content}")
                else:
                    print("Verse number out of range!")
            except Exception:
                print("Invalid verse number!")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
